import io
import json
import os
import re
import socket
import sys
import tempfile
import time
import unittest
from unittest import mock

import agent_tools as tools


class ValidationTests(unittest.TestCase):
    def test_schemas_are_openai_functions_and_restricted(self):
        self.assertEqual({s['function']['name'] for s in tools.TOOL_SCHEMAS},
                         {'pesquisar_documentacao', 'ler_pagina_https', 'inspecionar_termux', 'instalar_pacote'})
        for schema in tools.TOOL_SCHEMAS:
            self.assertEqual(schema['type'], 'function')
            self.assertFalse(schema['function']['parameters']['additionalProperties'])

    def test_rejects_unknown_extra_types_and_injection(self):
        for name, args in [
            ('shell', {'comando': 'id'}),
            ('inspecionar_termux', {'consulta': 'pwd', 'comando': 'id'}),
            ('inspecionar_termux', {'consulta': 'ls'}),
            ('inspecionar_termux', {'consulta': True}),
            ('instalar_pacote', {'pacote': '-y'}),
            ('instalar_pacote', {'pacote': 'pkg;id'}),
            ('instalar_pacote', {'pacote': 'foo bar'}),
            ('instalar_pacote', {'pacote': 'á'}),
            ('instalar_pacote', {'pacote': 'x' * 81}),
            ('pesquisar_documentacao', {'consulta': '  '}),
            ('ler_pagina_https', {'url': 17}),
            ('ler_pagina_https', {'url': 'https://x/\r\nHost: x'}),
        ]:
            with self.subTest(name=name, args=args):
                self.assertFalse(tools.executar_chamada(name, args)['ok'])
        self.assertFalse(tools.executar_chamada([], {})['ok'])
        self.assertFalse(tools.executar_chamada('inspecionar_termux', None)['ok'])

    def test_package_names_never_end_in_removal_suffix(self):
        pattern = next(s for s in tools.TOOL_SCHEMAS if s['function']['name'] == 'instalar_pacote')['function']['parameters']['properties']['pacote']['pattern']
        for name in ('nano-', 'a-', 'a--', 'x' * 79 + '-'):
            with self.subTest(name=name), mock.patch.object(tools, '_instalar') as install:
                self.assertIsNone(re.fullmatch(pattern, name))
                self.assertFalse(tools.executar_chamada('instalar_pacote', {'pacote': name}, confirm=True)['ok'])
                install.assert_not_called()
        for name in ('a', 'nano', 'foo-bar', 'libc++', 'x' * 80):
            with self.subTest(name=name):
                self.assertIsNotNone(re.fullmatch(pattern, name))
                self.assertEqual(tools._validar_args('instalar_pacote', {'pacote': name}), name)

    def test_inspection(self):
        self.assertEqual(tools.executar_chamada('inspecionar_termux', {'consulta': 'pwd'})['resultado']['diretorio'], os.getcwd())
        self.assertIn('versao', tools.executar_chamada('inspecionar_termux', {'consulta': 'python'})['resultado'])
        bins = tools.executar_chamada('inspecionar_termux', {'consulta': 'binarios'})['resultado']['binarios']
        self.assertEqual(set(bins), set(tools.BINARIOS))
        self.assertTrue(tools.executar_chamada('inspecionar_termux', {'consulta': 'uname'})['ok'])


class NetworkTests(unittest.TestCase):
    @staticmethod
    def record(ip):
        return (socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, '', (ip, 443))

    def test_block_nonpublic_and_mixed_dns(self):
        for addr in ('127.0.0.1', '10.1.2.3', '169.254.169.254', '192.168.1.2', '0.0.0.0', '224.0.0.1'):
            with self.subTest(addr=addr), mock.patch.object(tools.socket, 'getaddrinfo', return_value=[self.record('8.8.8.8'), self.record(addr)]):
                with self.assertRaises(ValueError):
                    tools._public_addresses('example.test', 443)

    def test_ipv6_and_ipv4_mapped(self):
        for addr in ('::1', 'fc00::1', 'fe80::1', '::ffff:127.0.0.1'):
            record = (socket.AF_INET6, socket.SOCK_STREAM, 6, '', (addr, 443, 0, 0))
            with self.subTest(addr=addr), mock.patch.object(tools.socket, 'getaddrinfo', return_value=[record]):
                with self.assertRaises(ValueError):
                    tools._public_addresses('example.test', 443)

    def test_rejects_bad_urls_before_network(self):
        for url in ('http://example.com', 'https://u:p@example.com/', 'https://example.com:444/',
                    'https://example.com/#fragment', 'https:///x', 'https://evil.test\r\n/x'):
            with self.subTest(url=url), mock.patch.object(tools, '_public_addresses') as resolve:
                self.assertFalse(tools.executar_chamada('ler_pagina_https', {'url': url})['ok'])
                resolve.assert_not_called()

    def test_search_quotes_input_and_returns_untrusted(self):
        data = b'{"query":{"search":[{"title":"Linux kernel","snippet":"<b>Linux</b>"}]}}'
        with mock.patch.object(tools, '_https_get', return_value=(data, 'application/json')) as get:
            result = tools.executar_chamada('pesquisar_documentacao', {'consulta': 'abc&foo=bar'})
        self.assertTrue(result['ok'])
        self.assertTrue(result['resultado']['dados_nao_confiaveis'])
        self.assertIn('srsearch=abc%26foo%3Dbar', get.call_args.args[0])
        self.assertEqual(result['resultado']['resultados'][0]['url'], 'https://pt.wikipedia.org/wiki/Linux_kernel')

    def test_search_rejects_malformed_json_shapes(self):
        for obj in (None, [], 'text', 42, {'query': None}, {'query': []},
                    {'query': {'search': None}}, {'query': {'search': {}}},
                    {'query': {'search': [None]}}, {'query': {'search': [{'title': []}]}},
                    {'query': {'search': [{'title': 'ok', 'snippet': None}]}}):
            with self.subTest(obj=obj), mock.patch.object(tools, '_https_get', return_value=(json.dumps(obj).encode(), 'application/json')):
                result = tools.executar_chamada('pesquisar_documentacao', {'consulta': 'teste'})
                self.assertFalse(result['ok'])
                self.assertIn('JSON', result['erro'])

    def test_https_connections_pin_resolved_ip_and_refuse_redirect(self):
        raw = mock.Mock()
        tls = mock.Mock()
        context = mock.Mock()
        context.wrap_socket.return_value = tls
        response = mock.Mock(status=302)
        with mock.patch.object(tools, '_public_addresses', return_value=[(socket.AF_INET, socket.SOCK_STREAM, 6, ('8.8.8.8', 443))]), \
             mock.patch.object(tools.socket, 'socket', return_value=raw), \
             mock.patch.object(tools.ssl, 'create_default_context', return_value=context), \
             mock.patch.object(tools.http.client, 'HTTPResponse', return_value=response):
            with self.assertRaisesRegex(ValueError, 'Redirecionamentos'):
                tools._https_get('https://example.com/page')
        raw.connect.assert_called_once_with(('8.8.8.8', 443))
        context.wrap_socket.assert_called_once_with(raw, server_hostname='example.com')

    def test_https_enforces_body_limit_without_content_length(self):
        raw, tls, context = mock.Mock(), mock.Mock(), mock.Mock()
        context.wrap_socket.return_value = tls
        response = mock.Mock(status=200)
        response.getheader.side_effect = lambda key, default=None: default
        response.read.side_effect = [b'a' * 8192] * (tools.MAX_WEB // 8192) + [b'x']
        with mock.patch.object(tools, '_public_addresses', return_value=[(socket.AF_INET, socket.SOCK_STREAM, 6, ('8.8.8.8', 443))]), \
             mock.patch.object(tools.socket, 'socket', return_value=raw), \
             mock.patch.object(tools.ssl, 'create_default_context', return_value=context), \
             mock.patch.object(tools.http.client, 'HTTPResponse', return_value=response):
            with self.assertRaisesRegex(ValueError, 'excede'):
                tools._https_get('https://example.com/')

    def test_https_success_marks_data_untrusted(self):
        with mock.patch.object(tools, '_https_get', return_value=(b'hello', 'text/plain')):
            r = tools.executar_chamada('ler_pagina_https', {'url': 'https://example.com'})
        self.assertEqual(r['resultado']['texto'], 'hello')
        self.assertTrue(r['resultado']['dados_nao_confiaveis'])


class ProcessTests(unittest.TestCase):
    def test_stdin_is_closed(self):
        result = tools._run([sys.executable, '-c', 'import sys; print(repr(sys.stdin.read()))'], 5)
        self.assertEqual(result['saida'].strip(), "''")
        self.assertEqual(result['codigo'], 0)

    def test_timeout_and_bounded_output(self):
        with self.assertRaises(TimeoutError):
            tools._run([sys.executable, '-c', 'import time; time.sleep(3)'], .1)
        result = tools._run([sys.executable, '-c', 'print("x" * 100000)'], 5)
        self.assertTrue(result['truncado'])
        self.assertLessEqual(len(result['saida'].encode()), tools.MAX_OUTPUT)

    def test_timeout_kills_group_even_after_leader_exits(self):
        with tempfile.TemporaryDirectory(prefix='protus_process_') as directory:
            marker = os.path.join(directory, 'survived')
            ready = os.path.join(directory, 'ready')
            child = ('import time, pathlib; pathlib.Path(' + repr(ready) + ').write_text("ready"); '
                     'time.sleep(1.5); pathlib.Path(' + repr(marker) + ').write_text("survived")')
            leader = ('import subprocess, sys, time, pathlib; '
                      'subprocess.Popen([sys.executable, "-c", ' + repr(child) + ']); '
                      'p=pathlib.Path(' + repr(ready) + '); '
                      'exec("while not p.exists():\\n time.sleep(0.01)")')
            processes = []
            popen = tools.subprocess.Popen
            def capture(*args, **kwargs):
                proc = popen(*args, **kwargs)
                processes.append(proc)
                return proc
            with mock.patch.object(tools.subprocess, 'Popen', side_effect=capture):
                with self.assertRaises(TimeoutError):
                    tools._run([sys.executable, '-c', leader], .8)
            self.assertTrue(os.path.exists(ready), 'filho não iniciou')
            self.assertEqual(processes[0].returncode, 0, 'líder não terminou normalmente')
            time.sleep(1.2)
            self.assertFalse(os.path.exists(marker), 'filho sobreviveu ao timeout')

    def test_timeout_after_output_eof_still_kills_process(self):
        code = 'import os, time; os.close(1); os.close(2); time.sleep(3)'
        with self.assertRaises(TimeoutError):
            tools._run([sys.executable, '-c', code], .2)

    def test_excess_output_is_drained_without_killing_process(self):
        with tempfile.TemporaryDirectory(prefix='protus_process_') as directory:
            marker = os.path.join(directory, 'completed')
            code = ('import os, pathlib; '
                    'os.write(1, b"x" * (3 * 65536)); '
                    'pathlib.Path(' + repr(marker) + ').write_text("done")')
            result = tools._run([sys.executable, '-c', code], 5)
            self.assertEqual(result['codigo'], 0)
            self.assertTrue(result['truncado'])
            self.assertEqual(result['saida'], 'x' * tools.MAX_OUTPUT)
            self.assertTrue(os.path.exists(marker))
        for size in (tools.MAX_OUTPUT - 1, tools.MAX_OUTPUT, tools.MAX_OUTPUT + 1):
            with self.subTest(size=size):
                result = tools._run([sys.executable, '-c', 'import os; os.write(1, b"x" * ' + str(size) + ')'], 5)
                self.assertEqual(result['codigo'], 0)
                self.assertEqual(result['truncado'], size > tools.MAX_OUTPUT)
                self.assertEqual(len(result['saida']), min(size, tools.MAX_OUTPUT))

    def test_nonzero_exit_reports_failure_and_output(self):
        failure = {'codigo': 7, 'saida': 'falhou', 'truncado': False}
        with mock.patch.object(tools, '_instalar', return_value=failure):
            result = tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)
        self.assertFalse(result['ok'])
        self.assertIn('7', result['erro'])
        self.assertEqual(result['resultado'], failure)
        with mock.patch.object(tools, '_run', return_value=failure):
            result = tools.executar_chamada('inspecionar_termux', {'consulta': 'uname'})
        self.assertFalse(result['ok'])
        self.assertEqual(result['resultado'], failure)

    def test_subprocess_uses_safe_arguments(self):
        original = tools.subprocess.Popen
        with mock.patch.object(tools.subprocess, 'Popen', wraps=original) as popen:
            tools._run([sys.executable, '-c', 'print(42)'], 5)
        self.assertIs(popen.call_args.kwargs['shell'], False)
        self.assertIs(popen.call_args.kwargs['stdin'], tools.subprocess.DEVNULL)


class InstallTests(unittest.TestCase):
    def termux_patches(self):
        return mock.patch.dict(os.environ, {'PREFIX': tools.TERMUX_PREFIX, 'TERMUX_VERSION': 'test'})

    def test_non_termux_and_no_confirmation_refuse(self):
        with mock.patch.dict(os.environ, {'PREFIX': '/usr', 'TERMUX_VERSION': ''}):
            with mock.patch.object(tools, '_confirmar_tty') as tty, mock.patch.object(tools, '_run') as run:
                self.assertFalse(tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)['ok'])
                self.assertFalse(tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm='yes')['ok'])
                tty.assert_not_called()
                run.assert_not_called()

    def test_refuses_installation_as_root(self):
        if not hasattr(os, 'geteuid'):
            self.skipTest('geteuid indisponível')
        with mock.patch.object(tools.os, 'geteuid', return_value=0), \
             mock.patch.object(tools, '_confirmar_tty') as tty, mock.patch.object(tools, '_run') as run:
            result = tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)
            self.assertFalse(result['ok'])
            self.assertIn('root', result['erro'])
            tty.assert_not_called()
            run.assert_not_called()

    def test_each_install_requires_exact_tty_confirmation(self):
        with self.termux_patches(), mock.patch.object(tools.os.path, 'isfile', return_value=True), \
             mock.patch.object(tools.os, 'access', return_value=True), \
             mock.patch.object(tools, '_confirmar_tty', side_effect=[False, True, False]) as tty, \
             mock.patch.object(tools, '_run', return_value={'codigo': 0}) as run:
            self.assertFalse(tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)['ok'])
            self.assertTrue(tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)['ok'])
            self.assertFalse(tools.executar_chamada('instalar_pacote', {'pacote': 'nano'}, confirm=True)['ok'])
        self.assertEqual(tty.call_count, 3)
        tty.assert_called_with(tools.PKG + ' install -y nano')
        run.assert_called_once_with([tools.PKG, 'install', '-y', 'nano'], tools.INSTALL_TIMEOUT)

    def test_tty_exact_match_and_unavailable(self):
        class FakeTTY(io.StringIO):
            def isatty(self):
                return True
            def close(self):
                pass
        # Writes and reads share one cursor; use explicit separate read method.
        stream = FakeTTY()
        stream.readline = lambda n: tools.PKG + ' install -y nano\n'
        with mock.patch('builtins.open', return_value=stream):
            self.assertTrue(tools._confirmar_tty(tools.PKG + ' install -y nano'))
        stream.readline = lambda n: 'sim\n'
        with mock.patch('builtins.open', return_value=stream):
            self.assertFalse(tools._confirmar_tty(tools.PKG + ' install -y nano'))
        with mock.patch('builtins.open', side_effect=OSError('sem tty')):
            self.assertFalse(tools._confirmar_tty('comando'))


if __name__ == '__main__':
    unittest.main()
