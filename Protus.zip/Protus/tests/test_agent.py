"""Testes da orquestração e interface: sem acesso à rede."""
import contextlib
import io
import json
import os
import unittest
from unittest import mock

import agent
import agent_tools
import protus
import qwen


def call(name, args, ident='1'):
    return {'id': ident, 'type': 'function', 'function': {'name': name, 'arguments': args}}


def response(*calls, content=None):
    return {'role': 'assistant', 'content': content, 'tool_calls': list(calls)}


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.env = mock.patch.dict(os.environ, {}, clear=True)
        self.env.start()
        self.addCleanup(self.env.stop)
        self.output = io.StringIO()
        self.redirect = contextlib.redirect_stdout(self.output)
        self.redirect.__enter__()
        self.addCleanup(self.redirect.__exit__, None, None, None)
        self.a = agent.Agente()

    def test_default_and_configured_endpoint_model_and_schemas(self):
        with mock.patch('qwen.chat', return_value={'role': 'assistant', 'content': 'Olá'}) as chat:
            self.assertEqual(self.a.responder('Teste'), 'Olá')
            self.assertEqual(chat.call_args.kwargs['endpoint'], qwen.DEFAULT_ENDPOINT)
            self.assertEqual(chat.call_args.kwargs['model'], qwen.DEFAULT_MODEL)
            self.assertIs(chat.call_args.kwargs['tools'], agent_tools.TOOL_SCHEMAS)
            with mock.patch.dict(os.environ, {'PROTUS_QWEN_ENDPOINT': 'http://localhost:8080/v1', 'PROTUS_QWEN_MODEL': 'local'}):
                self.a.responder('Outra')
                self.assertEqual(chat.call_args.kwargs['endpoint'], 'http://localhost:8080/v1')
                self.assertEqual(chat.call_args.kwargs['model'], 'local')
        self.assertIn('enviados ao provedor', self.output.getvalue())
        self.assertIn('não confiáveis', agent.PROMPT)
        self.assertIn('autorizadas', agent.PROMPT)

    def test_empty_and_too_long_never_call_api(self):
        with mock.patch('qwen.chat') as chat:
            self.assertEqual(self.a.responder('  '), '')
            self.assertIn('8000', self.a.responder('x' * 8001))
            chat.assert_not_called()

    def test_result_sent_untrusted_bounded_and_ordered(self):
        captured = []
        def fake_chat(messages, **kwargs):
            captured.append(json.loads(json.dumps(messages)))
            if len(captured) == 1:
                return response(call('inspecionar_termux', '{"consulta":"pwd"}'))
            return {'role': 'assistant', 'content': 'Pronto'}
        with mock.patch('qwen.chat', side_effect=fake_chat), mock.patch('agent_tools.executar_chamada', return_value={'ok': True, 'resultado': '"\\' * 10000}) as tool:
            self.assertEqual(self.a.responder('Verifique'), 'Pronto')
        tool.assert_called_once_with('inspecionar_termux', {'consulta': 'pwd'})
        msg = captured[1][-1]
        self.assertEqual(msg['role'], 'tool')
        self.assertEqual(msg['tool_call_id'], '1')
        self.assertLessEqual(len(msg['content']), 8000)
        self.assertTrue(json.loads(msg['content'])['truncado'])

    def test_disallowed_and_malformed_calls_never_execute(self):
        for nome, args in [('shell', '{"comando":"id"}'), ('inspecionar_termux', '{'),
                           ('inspecionar_termux', '[]'), ('inspecionar_termux', '{"consulta":"pwd","consulta":"uname"}'),
                           ('instalar_pacote', '{"pacote":"nano;id"}'),
                           ('ler_pagina_https', '{"url":"https://x/","other":1}')]:
            with self.subTest(nome=nome, args=args), mock.patch('agent_tools.executar_chamada') as tool:
                result = agent._executar_ferramenta(call(nome, args))
                self.assertFalse(result['ok'])
                tool.assert_not_called()

    def test_web_confirmation_is_per_call_and_denial_does_not_execute(self):
        with mock.patch('agent._confirmar_web', side_effect=[True, False, True]) as confirm, \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}) as tool:
            for name, arg in [('pesquisar_documentacao', '{"consulta":"abc"}'),
                              ('ler_pagina_https', '{"url":"https://example.org/"}'),
                              ('pesquisar_documentacao', '{"consulta":"abc"}')]:
                agent._executar_ferramenta(call(name, arg))
            self.assertEqual(confirm.call_count, 3)
            self.assertEqual(tool.call_count, 2)

    def test_web_tty_destination_and_closed_on_unavailable(self):
        tty = mock.MagicMock()
        tty.isatty.return_value = True
        tty.readline.return_value = 'sim\n'
        context = mock.MagicMock()
        context.__enter__.return_value = tty
        with mock.patch('builtins.open', return_value=context) as op:
            self.assertTrue(agent._confirmar_web('pesquisar_documentacao', 'a&b'))
            op.assert_called_once_with('/dev/tty', 'r+', encoding='utf-8')
            msg = tty.write.call_args.args[0]
            self.assertIn('srsearch=a%26b', msg)
            self.assertIn('a&b', msg)
            self.assertIn('provedor', msg)
            self.assertTrue(agent._confirmar_web('ler_pagina_https', 'https://example.org/path?q=x'))
            self.assertIn('https://example.org/path?q=x', tty.write.call_args.args[0])
            tty.readline.return_value = 'não\n'
            self.assertFalse(agent._confirmar_web('ler_pagina_https', 'https://example.org'))
        with mock.patch('builtins.open', side_effect=OSError):
            self.assertFalse(agent._confirmar_web('ler_pagina_https', 'https://example.org'))

    def test_installs_each_pass_true_and_execute_the_real_gate(self):
        with mock.patch('agent_tools._instalar', side_effect=[PermissionError('TTY recusado'), {'codigo': 0}]) as install:
            a = call('instalar_pacote', '{"pacote":"nano"}')
            self.assertFalse(agent._executar_ferramenta(a)['ok'])
            self.assertTrue(agent._executar_ferramenta(a)['ok'])
            self.assertEqual(install.call_args_list, [mock.call('nano', True), mock.call('nano', True)])
        self.assertIn('/dev/tty', self.output.getvalue())

    def test_five_api_and_tool_calls_max(self):
        with mock.patch('qwen.chat', return_value=response(call('inspecionar_termux', '{"consulta":"pwd"}'))) as api, \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}) as tool:
            self.assertIn('Limite', self.a.responder('x'))
            self.assertEqual(api.call_count, 5)
            self.assertEqual(tool.call_count, 4)
            self.assertIsNone(api.call_args_list[-1].kwargs['tools'])
            self.assertEqual(len(self.a.historico), 1)
        calls = [call('inspecionar_termux', '{"consulta":"pwd"}', str(i)) for i in range(6)]
        with mock.patch('qwen.chat', return_value=response(*calls)), mock.patch('agent_tools.executar_chamada') as tool:
            self.a.responder('x')
            tool.assert_not_called()

    def test_malformed_answer_and_error_reset_no_secret(self):
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': 'muito-secreta'}):
            for bad in ({}, response(call('x', '{}', '' )), {'role': 'assistant', 'content': []}):
                with mock.patch('qwen.chat', return_value=bad):
                    self.assertIn('Não foi possível', self.a.responder('x'))
                    self.assertEqual(len(self.a.historico), 1)
            with mock.patch('qwen.chat', side_effect=qwen.QwenError('muito-secreta')):
                result = self.a.responder('x')
                self.assertIn('OPENROUTER_API_KEY', result)
                self.assertNotIn('muito-secreta', result + self.output.getvalue())
            with mock.patch('qwen.chat', return_value={'role': 'assistant', 'content': 'muito-secreta'}):
                self.assertNotIn('muito-secreta', self.a.responder('x'))

    def test_key_in_tool_argument_refused_and_interrupt_aborts_turn(self):
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': 'segredo123'}), \
             mock.patch('agent._confirmar_web') as confirm, mock.patch('agent_tools.executar_chamada') as tool:
            result = agent._executar_ferramenta(call('ler_pagina_https', '{"url":"https://example.org/segredo123"}'))
            self.assertFalse(result['ok'])
            confirm.assert_not_called()
            tool.assert_not_called()
        with mock.patch('qwen.chat', return_value=response(call('pesquisar_documentacao', '{"consulta":"x"}'))) as chat, \
             mock.patch('agent._confirmar_web', side_effect=KeyboardInterrupt), \
             mock.patch('agent_tools.executar_chamada') as tool:
            self.assertIn('cancelada', self.a.responder('x'))
            self.assertEqual(chat.call_count, 1)
            tool.assert_not_called()
            self.assertEqual(len(self.a.historico), 1)

    def test_secrets_redacted_in_user_assistant_and_tool_results_before_every_request(self):
        captured = []
        key1, key2 = 'segredo-á123', 'chave-outra456'
        def fake_chat(messages, **kwargs):
            captured.append(json.loads(json.dumps(messages)))
            if len(captured) == 1:
                return response(call('inspecionar_termux', '{"consulta":"pwd"}', 'call-ok'),
                                content='Conteúdo: ' + key1)
            return {'role': 'assistant', 'content': 'Final: ' + key2}
        result = {'ok': True, key1: {'valor': [key2, key1], 'escapes': '\n' + key1}}
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': key1, 'PROTUS_API_KEY': key2}), \
             mock.patch('qwen.chat', side_effect=fake_chat), \
             mock.patch('agent_tools.executar_chamada', return_value=result):
            answer = self.a.responder('Minha mensagem: ' + key1 + ' e ' + key2)
            self.assertNotIn(key2, answer)
            for history in captured + [self.a.historico]:
                data = json.dumps(history, ensure_ascii=False)
                self.assertNotIn(key1, data)
                self.assertNotIn(key2, data)
            self.assertEqual(captured[1][-2]['tool_calls'][0]['id'], captured[1][-1]['tool_call_id'])
            self.assertIn('[CHAVE OCULTA]', captured[1][-2]['content'])
            self.assertIn('[CHAVE OCULTA]', captured[1][-1]['content'])
            json.loads(captured[1][-1]['content'])

    def test_secret_in_tool_call_structural_fields_or_escaped_json_is_rejected(self):
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': 'segredo123'}):
            calls = [call('ler_pagina_https', '{"url":"https://example.org/segredo123"}'),
                     call('inspecionar_termux', '{"consulta":"pwd"}', 'segredo123'),
                     call('segredo123', '{}'),
                     call('pesquisar_documentacao', r'{"consulta":"segredo\u0031\u0032\u0033"}')]
            for item in calls:
                with self.subTest(item=item), mock.patch('qwen.chat', return_value=response(item)) as api, \
                     mock.patch('agent_tools.executar_chamada') as tool, mock.patch('agent._confirmar_web') as confirm:
                    self.assertIn('recusada', self.a.responder('pergunta'))
                    self.assertEqual(api.call_count, 1)
                    tool.assert_not_called()
                    confirm.assert_not_called()
                    self.assertEqual(len(self.a.historico), 1)
                    self.assertNotIn('segredo123', json.dumps(self.a.historico))

    def test_existing_history_rechecked_when_environment_key_changes(self):
        history = [{'role': 'assistant', 'content': 'antiga-secreta'},
                   {'role': 'assistant', 'content': None, 'tool_calls': [call('inspecionar_termux', '{"consulta":"pwd"}', '1')]},
                   {'role': 'tool', 'tool_call_id': '1', 'content': r'{"x":"antiga-\u0073ecreta"}'}]
        self.a.historico.extend(history)
        with mock.patch.dict(os.environ, {'PROTUS_API_KEY': 'antiga-secreta'}), \
             mock.patch('qwen.chat', return_value={'role': 'assistant', 'content': 'ok'}) as api:
            self.a.responder('nova')
            saved = json.dumps(api.call_args.args[0], ensure_ascii=False)
            self.assertNotIn('antiga-secreta', saved)
            tool_message = next(m for m in api.call_args.args[0] if m['role'] == 'tool')
            self.assertIn('[CHAVE OCULTA]', json.loads(tool_message['content'])['x'])
        self.a.historico.extend([{'role': 'assistant', 'content': None,
                                  'tool_calls': [call('inspecionar_termux', '{"consulta":"pwd"}', 'mudou-key')]}])
        with mock.patch.dict(os.environ, {'PROTUS_API_KEY': 'mudou-key'}), mock.patch('qwen.chat') as api:
            self.assertIn('Não foi possível', self.a.responder('nova'))
            api.assert_not_called()
            self.assertEqual(len(self.a.historico), 1)

    def test_unusual_keys_do_not_corrupt_serialized_tool_result(self):
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': 'true'}), \
             mock.patch('qwen.chat', return_value=response(call('inspecionar_termux', '{"consulta":"pwd"}'))) as api, \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}):
            answer = self.a.responder('x')
            self.assertIn('Não foi possível', answer)
            self.assertEqual(api.call_count, 1)
            self.assertEqual(len(self.a.historico), 1)
        with mock.patch.dict(os.environ, {'OPENROUTER_API_KEY': 'CHAVE', 'PROTUS_API_KEY': 'xyz'}):
            self.assertNotIn('CHAVE', agent._sem_chaves('CHAVE'))
            self.assertNotIn('xyz', agent._sem_chaves('xyz'))

    def test_terminal_response_controls_and_bidi_are_visible_not_executed(self):
        hostile = 'linha\n\x1b]52;c;SGVsbG8=\x07\x1b[31mvermelho\x9b2J\r\x00\u202etxt\u2066fim\u2069'
        with mock.patch('qwen.chat', return_value={'role': 'assistant', 'content': hostile}):
            answer = self.a.responder('oi')
        for c in ('\x1b', '\x07', '\x9b', '\r', '\x00', '\u202e', '\u2066', '\u2069'):
            self.assertNotIn(c, answer)
        self.assertIn('linha\n', answer)
        self.assertIn(r'\x1b]52', answer)
        self.assertIn(r'\u202e', answer)
        self.assertIn('vermelho', answer)

    def test_web_confirmation_escapes_bidi_and_terminal_controls(self):
        tty = mock.MagicMock()
        tty.isatty.return_value = True
        tty.readline.return_value = 'sim\n'
        context = mock.MagicMock()
        context.__enter__.return_value = tty
        with mock.patch('builtins.open', return_value=context):
            for name, value in [('pesquisar_documentacao', 'abc\u202edef\x1b]0;x\x07'),
                                ('ler_pagina_https', 'https://example.org/\u2066abc\u2069')]:
                self.assertTrue(agent._confirmar_web(name, value))
                msg = tty.write.call_args.args[0]
                for c in ('\u202e', '\u2066', '\u2069', '\x1b', '\x07'):
                    self.assertNotIn(c, msg)
                self.assertTrue(r'\u202e' in msg or r'\u2066' in msg)
            self.assertIn('https://example.org/', tty.write.call_args.args[0])

    def test_last_round_forces_no_tools_and_returns_final_answer(self):
        calls = [response(call('inspecionar_termux', '{"consulta":"pwd"}', str(i))) for i in range(4)]
        calls.append({'role': 'assistant', 'content': 'Resumo final'})
        with mock.patch('qwen.chat', side_effect=calls) as api, \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}) as tool:
            self.assertEqual(self.a.responder('x'), 'Resumo final')
            self.assertEqual(tool.call_count, 4)
            self.assertIsNone(api.call_args_list[-1].kwargs['tools'])
            self.assertEqual(api.call_count, 5)

    def test_last_round_unexpected_call_does_not_execute_and_reports_prior_effects(self):
        calls = [response(call('inspecionar_termux', '{"consulta":"pwd"}', str(i))) for i in range(4)]
        calls.append(response(call('instalar_pacote', '{"pacote":"nano"}', 'last')))
        with mock.patch('qwen.chat', side_effect=calls) as api, \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}) as tool:
            answer = self.a.responder('x')
            self.assertEqual(api.call_count, 5)
            self.assertIsNone(api.call_args_list[-1].kwargs['tools'])
            self.assertEqual(tool.call_count, 4)
            self.assertIn('não foi executada', answer)
            self.assertIn('4 chamadas', answer)
            self.assertIn('podem ter produzido efeitos', answer)
            self.assertIn('Não foi obtida resposta final', answer)
            self.assertEqual(len(self.a.historico), 1)

    def test_failed_final_api_reports_possible_prior_effects(self):
        answers = [response(call('inspecionar_termux', '{"consulta":"pwd"}')), qwen.QwenError('erro')]
        with mock.patch('qwen.chat', side_effect=answers), \
             mock.patch('agent_tools.executar_chamada', return_value={'ok': True}):
            answer = self.a.responder('x')
            self.assertIn('1 chamadas', answer)
            self.assertIn('podem ter produzido efeitos', answer)
            self.assertIn('sem resposta final', answer)

    def test_cancel_and_history_limit(self):
        with mock.patch('qwen.chat', side_effect=KeyboardInterrupt):
            self.assertIn('cancelada', self.a.responder('x'))
            self.assertEqual(len(self.a.historico), 1)
        self.a.historico.extend([{'role': 'assistant', 'content': 'x'}] * agent.MAX_ASSISTENTES)
        with mock.patch('qwen.chat', return_value={'role': 'assistant', 'content': 'ok'}) as api:
            self.a.responder('nova')
            self.assertEqual(api.call_args.args[0][1]['content'], 'nova')
        self.assertIn('Histórico da IA limpo', self.output.getvalue())


class InterfaceTests(unittest.TestCase):
    def test_dispatch_and_empty(self):
        with mock.patch('protus.perguntar_ia') as ask, mock.patch('protus.modo_ia') as mode:
            protus.executar('   ')
            ask.assert_not_called()
            protus.executar('qual é o kernel?')
            ask.assert_called_once_with('qual é o kernel?')
            protus.executar('ia teste')
            ask.assert_called_with('teste')
            protus.executar('modo ia')
            mode.assert_called_once()
            self.assertFalse(protus.executar('sair'))

    def test_interactive_session_clear_empty_and_exit(self):
        with mock.patch('protus.Agente') as cls, mock.patch('builtins.input', side_effect=['', 'pergunta', 'limpar histórico', 'voltar']), contextlib.redirect_stdout(io.StringIO()):
            protus.modo_ia()
            cls.assert_called_once()
            cls.return_value.responder.assert_called_once_with('pergunta')
            cls.return_value.limpar.assert_called_once()

    def test_fresh_main_session(self):
        with mock.patch('protus.Agente') as cls, mock.patch('builtins.input', side_effect=['sair']), contextlib.redirect_stdout(io.StringIO()):
            protus.assistente()
            cls.assert_called_once()
            self.assertIs(protus._agente_padrao, cls.return_value)


if __name__ == '__main__':
    unittest.main()
