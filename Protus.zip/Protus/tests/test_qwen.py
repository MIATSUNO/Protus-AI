"""Testes do cliente Qwen: transporte simulado, nenhuma rede real."""
import io
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import qwen


def response(message):
    return json.dumps({'choices': [{'message': message}]}).encode('utf-8')


class FakeResponse:
    def __init__(self, data):
        self.data = io.BytesIO(data)
        self.read_size = None
    def __enter__(self):
        return self
    def __exit__(self, *args):
        self.data.close()
    def read(self, size):
        self.read_size = size
        return self.data.read(size)


class TestQwen(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {}, clear=True)
        self.env.start()
        self.addCleanup(self.env.stop)
        self.opener_patch = patch('qwen.urllib.request.build_opener')
        self.build = self.opener_patch.start()
        self.addCleanup(self.opener_patch.stop)
        self.opener = self.build.return_value
        self.mock_response = FakeResponse(response({'role': 'assistant', 'content': 'Olá'}))
        self.opener.open.return_value = self.mock_response
        self.messages = [{'role': 'user', 'content': 'Oi'}]

    def test_payload_cabecalhos_modelo_timeout_sem_proxy(self):
        with patch.dict(os.environ, {'OPENROUTER_API_KEY': 'segredo'}):
            out = qwen.chat(self.messages, timeout=7)
        self.assertEqual(out, {'role': 'assistant', 'content': 'Olá'})
        req = self.opener.open.call_args.args[0]
        self.assertEqual(req.full_url, qwen.DEFAULT_ENDPOINT)
        self.assertEqual(req.get_method(), 'POST')
        self.assertEqual(req.get_header('Authorization'), 'Bearer segredo')
        self.assertEqual(req.get_header('Content-type'), 'application/json')
        self.assertEqual(json.loads(req.data), {'model': 'qwen/qwen3.8-27b', 'messages': self.messages})
        self.assertEqual(self.opener.open.call_args.kwargs['timeout'], 7)
        self.assertEqual(self.mock_response.read_size, 1048577)
        handlers = self.build.call_args.args
        self.assertIsInstance(handlers[0], urllib.request.ProxyHandler)
        self.assertEqual(handlers[0].proxies, {})
        self.assertIsInstance(handlers[1], qwen._NoRedirect)
        self.assertIsNone(handlers[1].redirect_request(None, None, 302, '', {}, 'https://evil.test'))

    def test_tool_calls_preservadas_sem_execucao(self):
        calls = [{'id': 'call_1', 'type': 'function', 'function': {'name': 'testar', 'arguments': '{"x":1}'}}]
        self.opener.open.return_value = FakeResponse(response({'role': 'assistant', 'content': None, 'tool_calls': calls}))
        tools = [{'type': 'function', 'function': {'name': 'testar'}}]
        out = qwen.chat(self.messages, tools, endpoint='http://127.0.0.1:8000/v1/chat/completions', model='local')
        self.assertEqual(out, {'role': 'assistant', 'content': None, 'tool_calls': calls})
        payload = json.loads(self.opener.open.call_args.args[0].data)
        self.assertEqual(payload['tools'], tools)
        self.assertEqual(payload['model'], 'local')
        self.assertIsNone(self.opener.open.call_args.args[0].get_header('Authorization'))

    def test_ordem_de_chaves(self):
        for env, explicit, expected in [({'OPENROUTER_API_KEY': 'um', 'PROTUS_API_KEY': 'dois'}, None, 'um'),
                                        ({'PROTUS_API_KEY': 'dois'}, None, 'dois'),
                                        ({'OPENROUTER_API_KEY': 'um'}, 'tres', 'tres')]:
            with self.subTest(env=env, explicit=explicit), patch.dict(os.environ, env, clear=True):
                self.opener.open.return_value = FakeResponse(response({'role': 'assistant', 'content': 'ok'}))
                qwen.chat(self.messages, api_key=explicit)
                self.assertEqual(self.opener.open.call_args.args[0].get_header('Authorization'), 'Bearer ' + expected)

    def test_chaves_em_loopback_nao_usam_openrouter_automaticamente(self):
        endpoints = ('http://localhost:8000/x', 'http://127.0.0.1/x',
                     'http://[::1]:123/x', 'https://localhost/x',
                     'https://127.0.0.1/x', 'https://[::1]/x')
        casos = [({'OPENROUTER_API_KEY': 'segredo'}, None, None),
                 ({'OPENROUTER_API_KEY': 'segredo', 'PROTUS_API_KEY': ''}, None, None),
                 ({'OPENROUTER_API_KEY': 'segredo', 'PROTUS_API_KEY': 'local'}, None, 'Bearer local'),
                 ({'OPENROUTER_API_KEY': 'segredo'}, 'explicita', 'Bearer explicita'),
                 ({'OPENROUTER_API_KEY': 'segredo', 'PROTUS_API_KEY': 'local'},
                  'explicita', 'Bearer explicita')]
        for endpoint in endpoints:
            for env, explicit, expected in casos:
                with self.subTest(endpoint=endpoint, env=env, explicit=explicit), patch.dict(os.environ, env, clear=True):
                    self.opener.open.return_value = FakeResponse(response({'role': 'assistant', 'content': 'ok'}))
                    qwen.chat(self.messages, endpoint=endpoint, api_key=explicit)
                    self.assertEqual(self.opener.open.call_args.args[0].get_header('Authorization'), expected)

    def test_chave_local_invalida_nao_faz_fallback(self):
        with patch.dict(os.environ, {'OPENROUTER_API_KEY': 'segredo', 'PROTUS_API_KEY': 'ruim\nchave'}):
            with self.assertRaisesRegex(qwen.QwenError, 'Chave de API inválida'):
                qwen.chat(self.messages, endpoint='http://localhost')
        self.build.assert_not_called()

    def test_endpoint_permitido(self):
        for endpoint in ('http://localhost:8000/x', 'http://127.0.0.1/x', 'http://[::1]:123/x', 'https://example.org/x'):
            with self.subTest(endpoint=endpoint):
                self.opener.open.return_value = FakeResponse(response({'role': 'assistant', 'content': 'ok'}))
                qwen.chat(self.messages, endpoint=endpoint, api_key='key')

    def test_endpoint_invalido(self):
        for endpoint in ('http://example.com/', 'ftp://localhost/a', 'http://localhost.evil/x',
                         'http://user:secret@localhost/x', 'https://user@host/x',
                         'http://127.0.0.2/x', 'http://localhost:0/x',
                         'https://host:99999/x', 'https://host/a#frag',
                         'https://host/\nAuthorization:segredo', 'https://host\\@evil/x',
                         'https://%65xample.com/x', '', 'http:///path'):
            with self.subTest(endpoint=endpoint), self.assertRaises(qwen.QwenError):
                qwen.chat(self.messages, endpoint=endpoint, api_key='segredo')
        self.build.assert_not_called()

    def test_sem_chave_remoto_e_chave_invalida(self):
        for kwargs in ({}, {'api_key': 'bad\nkey'}, {'api_key': ''}):
            with self.subTest(kwargs=kwargs), self.assertRaises(qwen.QwenError):
                qwen.chat(self.messages, **kwargs)
        self.build.assert_not_called()

    def test_limites_historico_e_turnos(self):
        history = [{'role': 'user', 'content': 'x'}, {'role': 'assistant', 'content': 'y'},
                   {'role': 'tool', 'content': 'z', 'tool_call_id': '1'}]
        with self.assertRaisesRegex(qwen.QwenError, 'mensagens'):
            qwen.chat(history, endpoint='http://localhost', max_history_messages=2)
        with self.assertRaisesRegex(qwen.QwenError, 'turnos'):
            qwen.chat(history, endpoint='http://localhost', max_turns=1)
        self.assertEqual(qwen.chat(history, endpoint='http://localhost', max_turns=2, max_history_messages=3)['content'], 'Olá')
        self.assertEqual(json.loads(self.opener.open.call_args.args[0].data)['messages'], history)

    def test_validacao(self):
        for kwargs in ({'timeout': 0}, {'timeout': float('nan')}, {'timeout': True},
                       {'max_response_bytes': 0}, {'max_turns': False},
                       {'max_history_messages': -1}, {'model': ''}, {'tools': {}},
                       {'api_key': 'bad\rkey'}):
            with self.subTest(kwargs=kwargs), self.assertRaises(qwen.QwenError):
                qwen.chat(self.messages, endpoint='http://localhost', **kwargs)
        for messages in ([], {}, [None], [{'content': 'oi'}]):
            with self.subTest(messages=messages), self.assertRaises(qwen.QwenError):
                qwen.chat(messages, endpoint='http://localhost')
        with self.assertRaises(qwen.QwenError):
            qwen.chat([{'role': 'user', 'content': object()}], endpoint='http://localhost')
        self.build.assert_not_called()

    def test_tamanho_e_resposta_invalida(self):
        self.opener.open.return_value = FakeResponse(b'x' * 11)
        with self.assertRaisesRegex(qwen.QwenError, 'max_response_bytes'):
            qwen.chat(self.messages, endpoint='http://localhost', max_response_bytes=10)
        for body in (b'nao-json', b'\xff', b'{}', b'{"choices": []}',
                     response({'role': 'user', 'content': 'oi'}),
                     response({'role': 'assistant', 'content': None}),
                     response({'role': 'assistant', 'content': [], 'tool_calls': []}),
                     response({'role': 'assistant', 'content': None, 'tool_calls': [{'id': '1'}]})):
            with self.subTest(body=body):
                self.opener.open.return_value = FakeResponse(body)
                with self.assertRaisesRegex(qwen.QwenError, 'inválida'):
                    qwen.chat(self.messages, endpoint='http://localhost')

    def test_http_error_fecha_corpo_e_mantem_erros_sanitizados(self):
        for code, expected in ((302, 'Redirecionamento'), (401, '401')):
            with self.subTest(code=code):
                body = io.BytesIO(b'segredo')
                self.opener.open.side_effect = urllib.error.HTTPError(
                    'https://x/segredo', code, 'segredo', {}, body)
                with self.assertRaises(qwen.QwenError) as result:
                    qwen.chat(self.messages, api_key='segredo')
                self.assertTrue(body.closed)
                self.assertIn(expected, str(result.exception))
                self.assertNotIn('segredo', str(result.exception))
                self.assertTrue(result.exception.__suppress_context__)

    def test_http_error_falha_ao_fechar_e_sanitizada(self):
        body = io.BytesIO(b'segredo')
        error = urllib.error.HTTPError('https://x/segredo', 401, 'segredo', {}, body)
        self.opener.open.side_effect = error
        with patch.object(error, 'close', side_effect=OSError('segredo')):
            with self.assertRaises(qwen.QwenError) as result:
                qwen.chat(self.messages, api_key='segredo')
        error.close()
        self.assertTrue(body.closed)
        self.assertIn('401', str(result.exception))
        self.assertNotIn('segredo', str(result.exception))
        self.assertTrue(result.exception.__suppress_context__)

    def test_erros_sanitizados_e_redirect(self):
        for exc, expected in [(urllib.error.HTTPError('https://x/segredo', 302, 'segredo', {}, None), 'Redirecionamento'),
                              (urllib.error.HTTPError('https://x/segredo', 401, 'segredo', {}, None), '401'),
                              (urllib.error.URLError('segredo'), 'Falha'),
                              (TimeoutError('segredo'), 'Falha')]:
            with self.subTest(exc=exc):
                self.opener.open.side_effect = exc
                with self.assertRaises(qwen.QwenError) as result:
                    qwen.chat(self.messages, api_key='segredo')
                self.assertIn(expected, str(result.exception))
                self.assertNotIn('segredo', str(result.exception))
                self.assertTrue(result.exception.__suppress_context__)


if __name__ == '__main__':
    unittest.main()
