"""Testes do gerador HTML, sem alterar arquivos do aplicativo."""
import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import geradorHTML as html_app


class TestHTML(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='protus_html_')
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'pagina.html'

    def test_titulo_escapado_e_conteudo_html_literal(self):
        result = html_app.gerar_html('<script>"&\'</script>', '<b>Olá</b>')
        self.assertIn('&lt;script&gt;&quot;&amp;&#x27;&lt;/script&gt;', result)
        self.assertIn('<b>Olá</b>', result)
        self.assertIn('<meta charset="utf-8">', result)
        self.assertIn('<html lang="pt-BR">', result)

    def test_cria_arquivo_utf8(self):
        content = html_app.gerar_html('Título', '<p>ação</p>')
        with patch('builtins.input', side_effect=AssertionError('Não deveria pedir confirmação')):
            self.assertTrue(html_app.salvar_arquivo(self.path, content))
        self.assertEqual(self.path.read_bytes(), content.encode('utf-8'))

    def test_sobrescrita_negada_preserva_arquivo(self):
        for resposta in ('', 'n', 'não', 'talvez'):
            with self.subTest(resposta=resposta):
                self.path.write_text('original', encoding='utf-8')
                with patch('builtins.input', return_value=resposta), contextlib.redirect_stdout(io.StringIO()):
                    self.assertFalse(html_app.salvar_arquivo(self.path, 'novo'))
                self.assertEqual(self.path.read_text(encoding='utf-8'), 'original')

    def test_sobrescrita_confirmada(self):
        for resposta in ('s', 'SIM', ' Sim '):
            with self.subTest(resposta=resposta):
                self.path.write_text('anterior mais longo', encoding='utf-8')
                with patch('builtins.input', return_value=resposta):
                    self.assertTrue(html_app.salvar_arquivo(self.path, 'novo'))
                self.assertEqual(self.path.read_text(encoding='utf-8'), 'novo')

    def test_caminho_vazio_rejeitado(self):
        for caminho in ('', '   '):
            with self.subTest(caminho=caminho), self.assertRaises(ValueError):
                html_app.salvar_arquivo(caminho, 'x')

    @unittest.skipUnless(hasattr(os, 'symlink'), 'links simbólicos indisponíveis')
    def test_link_simbolico_existente_e_dangling_rejeitados(self):
        target = Path(self.temp.name) / 'segredo'
        target.write_text('preservado', encoding='utf-8')
        for nome, dest in [('existente', target), ('dangling', Path(self.temp.name) / 'inexistente')]:
            with self.subTest(nome=nome):
                link = Path(self.temp.name) / nome
                os.symlink(dest, link)
                with patch('builtins.input', side_effect=AssertionError('Não deve solicitar permissão')):
                    with self.assertRaises(ValueError):
                        html_app.salvar_arquivo(link, 'alterado')
                self.assertEqual(target.read_text(encoding='utf-8'), 'preservado')
                self.assertFalse((Path(self.temp.name) / 'inexistente').exists())

    @unittest.skipUnless(hasattr(os, 'O_NOFOLLOW') and hasattr(os, 'symlink'), 'O_NOFOLLOW indisponível')
    def test_troca_por_link_entre_confirmacao_e_abertura(self):
        target = Path(self.temp.name) / 'segredo'
        target.write_text('preservado', encoding='utf-8')
        self.path.write_text('original', encoding='utf-8')
        def trocar(_prompt):
            self.path.unlink()
            os.symlink(target, self.path)
            return 's'
        with patch('builtins.input', side_effect=trocar):
            with self.assertRaises(OSError):
                html_app.salvar_arquivo(self.path, 'ataque')
        self.assertEqual(target.read_text(encoding='utf-8'), 'preservado')

    def test_main_cria_arquivo(self):
        with patch('builtins.input', side_effect=[str(self.path), '<titulo>', '<i>texto</i>']), contextlib.redirect_stdout(io.StringIO()) as out:
            html_app.main()
        self.assertIn('&lt;titulo&gt;', self.path.read_text(encoding='utf-8'))
        self.assertIn('<i>texto</i>', self.path.read_text(encoding='utf-8'))
        self.assertIn('salvo', out.getvalue())


if __name__ == '__main__':
    unittest.main()
