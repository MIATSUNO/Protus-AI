# Protus — entrega

Assistente de linha de comando em Python, com comandos locais, gerador HTML e integração opcional de IA. Usa apenas a biblioteca padrão do Python; consulte [CONFIGURACAO_IA.md](CONFIGURACAO_IA.md) para configurar endpoint, modelo e chave sem digitá-la no histórico do shell, além de custos e privacidade.

## Início

No Termux, com Python instalado, entre na pasta do projeto e execute:

```sh
python protus.py
```

Digite `ajuda` para listar comandos e `sair` para encerrar. Exemplos: `calculadora 2 + 2`, `horas`, `wikipedia Python`, `html` e `modo ia`. A IA remota precisa de chave e acesso à rede; veja o guia antes de usá-la. Comandos de rede dependem dos utilitários disponíveis e das permissões do ambiente. O Protus não exige root; a instalação de pacotes pela IA recusa execução como root.

`html` escapa o título, mas insere o corpo como **HTML literal**, sem sanitização: não use conteúdo não confiável, pois ele pode conter scripts. Notas e HTML pedem confirmação antes de sobrescrever arquivos existentes.

## Limitações e verificação

- A pesquisa da ferramenta de IA usa apenas a Wikipédia em português; a leitura HTTPS é uma ferramenta separada. A confirmação em TTY das ferramentas de IA não se aplica aos comandos legados do menu, que podem abrir páginas ou consultar a Wikipédia diretamente.
- A instalação pela IA usa `pkg install -y` do Termux, somente após aprovação exata em TTY; ela pode executar scripts e ser interrompida após 300 segundos, com efeitos parciais.
- NetHunter rootless não é root. Não presume suporte a recursos privilegiados nem que o ambiente/chroot Kali satisfaça as verificações específicas do Termux; redes e utilitários podem ter restrições. Não foram testados Termux nem NetHunter rootless.
- Os testes automatizados passaram no ambiente de entrega com **Python 3.14.4**: 68 testes via `python -B -m unittest discover -s tests -v`. Isso não estabelece compatibilidade com outras versões; rede real, provedor de IA e instalação real no Termux não foram validados. Os testes isolados não substituem validação em aparelho.
