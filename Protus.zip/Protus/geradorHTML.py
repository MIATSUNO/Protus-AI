"""Gerador HTML do Protus, sem dependências externas."""
import html
import os


def salvar_arquivo(caminho, conteudo):
    """Cria em UTF-8; só substitui um arquivo existente após confirmação.

    Não segue links simbólicos na abertura quando a plataforma suporta O_NOFOLLOW.
    """
    caminho = os.fspath(caminho)
    if not caminho.strip():
        raise ValueError('Informe um caminho de arquivo.')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    try:
        fd = os.open(caminho, flags, 0o666)
    except FileExistsError:
        if os.path.islink(caminho):
            raise ValueError('Por segurança, não é permitido sobrescrever links simbólicos.')
        resposta = input(f'O arquivo "{caminho}" já existe. Sobrescrever? [s/N] ').strip().casefold()
        if resposta not in ('s', 'sim'):
            print('Operação cancelada; arquivo preservado.')
            return False
        flags = os.O_WRONLY | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0)
        fd = os.open(caminho, flags)
    with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as arquivo:
        arquivo.write(conteudo)
    return True


def gerar_html(titulo, conteudo):
    """Título escapado; conteúdo é HTML fornecido deliberadamente pelo usuário."""
    return ('<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n'
            '  <meta charset="utf-8">\n'
            f'  <title>{html.escape(titulo)}</title>\n'
            '</head>\n<body>\n' + conteudo + '\n</body>\n</html>\n')


def main():
    print('Gerador HTML — o conteúdo aceita marcação HTML literal.')
    caminho = input('Nome do arquivo HTML: ').strip()
    titulo = input('Título da página: ')
    conteudo = input('Conteúdo da página (HTML permitido): ')
    try:
        if salvar_arquivo(caminho, gerar_html(titulo, conteudo)):
            print(f'Arquivo HTML "{caminho}" salvo.')
    except (OSError, ValueError) as erro:
        print(f'Não foi possível salvar o HTML: {erro}')


if __name__ == '__main__':
    try:
        main()
    except (EOFError, KeyboardInterrupt):
        print('\nOperação cancelada.')
