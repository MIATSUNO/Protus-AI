"""Cliente Qwen para Chat Completions, apenas com a biblioteca padrão.

Uso por outro módulo::

    from qwen import chat, QwenError
    message = chat([{"role": "user", "content": "Olá!"}], tools=None)
    # message: {"role": "assistant", "content": str | None,
    #           "tool_calls": list} (tool_calls só aparece se fornecido).

Interface: chat(messages, tools=None, *, endpoint=DEFAULT_ENDPOINT,
model=DEFAULT_MODEL, api_key=None, timeout=30, max_response_bytes=1048576,
max_history_messages=100, max_turns=20). A chave explícita tem precedência.
Se for None, endpoints loopback (HTTP ou HTTPS) usam somente PROTUS_API_KEY,
quando definida; nunca usam automaticamente OPENROUTER_API_KEY e podem ser
usados sem chave. Em endpoints não loopback, usa OPENROUTER_API_KEY e depois
PROTUS_API_KEY; eles exigem chave. Não há integração
ChatGPT. tools segue o formato OpenAI Chat Completions. O retorno preserva as
chamadas, incluindo arguments como string JSON; nunca executa ferramentas.

Cada chamada faz uma requisição. max_turns limita o número de respostas do
assistente contabilizadas no histórico enviado, incluindo a resposta pedida.
max_history_messages limita o número de mensagens enviadas. Ao atingir um
limite, QwenError é lançado, sem truncamento automático (que poderia separar
uma chamada de ferramenta do seu resultado). O chamador mantém o histórico,
contabiliza turnos ao reiniciá-lo e decide executar ferramentas. timeout é o
limite de inatividade de socket em segundos, não um prazo total de operação.

Endpoint: HTTPS ou HTTP apenas para localhost, 127.0.0.1 ou [::1], sem
credenciais na URL. HTTPS aceita hosts privados também: quem configura endpoint
é responsável por sua confiabilidade; isso não é uma proteção geral de SSRF
contra destinos HTTPS arbitrários. Proxy de ambiente e redirects são desativados
para não enviar a chave a intermediários ou destinos inesperados. Erros são
QwenError com texto genérico, sem corpo HTTP nem detalhes potencialmente secretos.
"""
import json
import math
import os
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions'
DEFAULT_MODEL = 'qwen/qwen3.8-27b'


class QwenError(Exception):
    """Erro de configuração, transporte ou resposta do provedor."""


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _endpoint_info(endpoint):
    if not isinstance(endpoint, str) or not endpoint or any(
        c.isspace() or ord(c) < 32 or ord(c) == 127 or c == '\\' for c in endpoint
    ):
        raise QwenError('Endpoint inválido.')
    try:
        parts = urllib.parse.urlsplit(endpoint)
        hostname = parts.hostname
        port = parts.port
        if (parts.scheme.lower() not in ('http', 'https') or not hostname
                or parts.username is not None or parts.password is not None
                or parts.fragment or '%' in parts.netloc
                or (port is not None and port == 0)):
            raise ValueError
        is_loopback = hostname.lower() in ('localhost', '127.0.0.1', '::1')
        if parts.scheme.lower() == 'http' and not is_loopback:
            raise ValueError
    except ValueError:
        raise QwenError('Endpoint inválido: use HTTPS ou HTTP local, sem credenciais.') from None
    return is_loopback


def _positive_int(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise QwenError(name + ' deve ser inteiro positivo.')


def chat(messages, tools=None, *, endpoint=DEFAULT_ENDPOINT, model=DEFAULT_MODEL,
         api_key=None, timeout=30, max_response_bytes=1048576,
         max_history_messages=100, max_turns=20):
    """Envia um histórico e devolve a mensagem do assistente, sem executar tools.

    A chave explícita prevalece; sem ela, loopback usa somente PROTUS_API_KEY
    ou nenhuma chave, enquanto outros endpoints usam OPENROUTER_API_KEY e,
    na ausência desta, PROTUS_API_KEY. Endpoints não loopback exigem chave.
    """
    is_loopback = _endpoint_info(endpoint)
    for value, name in ((max_response_bytes, 'max_response_bytes'),
                        (max_history_messages, 'max_history_messages'),
                        (max_turns, 'max_turns')):
        _positive_int(value, name)
    if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
            or not math.isfinite(timeout) or timeout <= 0):
        raise QwenError('timeout deve ser um número positivo finito.')
    if not isinstance(model, str) or not model.strip():
        raise QwenError('model deve ser uma string não vazia.')
    if not isinstance(messages, list) or not messages or not all(
        isinstance(m, dict) and isinstance(m.get('role'), str) for m in messages
    ):
        raise QwenError('messages deve ser uma lista não vazia de mensagens com role.')
    if len(messages) > max_history_messages:
        raise QwenError('Limite de mensagens do histórico excedido.')
    if sum(m['role'] == 'assistant' for m in messages) >= max_turns:
        raise QwenError('Limite de turnos atingido.')
    if tools is not None and (not isinstance(tools, list) or not all(isinstance(t, dict) for t in tools)):
        raise QwenError('tools deve ser uma lista de objetos ou None.')
    if api_key is None:
        if is_loopback:
            api_key = os.environ.get('PROTUS_API_KEY') or None
        else:
            api_key = os.environ.get('OPENROUTER_API_KEY') or os.environ.get('PROTUS_API_KEY')
    if api_key is not None and (not isinstance(api_key, str) or not api_key.strip()
                                or any(ord(c) < 32 or ord(c) == 127 for c in api_key)):
        raise QwenError('Chave de API inválida.')
    if not api_key and not is_loopback:
        raise QwenError('Chave de API não configurada.')
    payload = {'model': model, 'messages': messages}
    if tools is not None:
        payload['tools'] = tools
    try:
        data = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, UnicodeError, RecursionError):
        raise QwenError('Não foi possível serializar a requisição JSON.') from None
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    if api_key:
        headers['Authorization'] = 'Bearer ' + api_key
    try:
        req = urllib.request.Request(endpoint, data=data, headers=headers, method='POST')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
        with opener.open(req, timeout=timeout) as response:
            raw = response.read(max_response_bytes + 1)
        if len(raw) > max_response_bytes:
            raise QwenError('Resposta excede max_response_bytes.')
    except QwenError:
        raise
    except urllib.error.HTTPError as error:
        code = error.code if isinstance(error.code, int) else None
        try:
            error.close()
        except Exception:
            # Mesmo falhas ao fechar podem conter detalhes sensíveis.
            pass
        if code is not None and 300 <= code < 400:
            raise QwenError('Redirecionamento HTTP recusado.') from None
        raise QwenError('Erro HTTP do provedor' + (f' ({code}).' if code is not None else '.')) from None
    except Exception:
        # Erros de rede e suas mensagens podem conter endpoint ou dados sensíveis.
        raise QwenError('Falha ao conectar ou ler a resposta do provedor.') from None
    try:
        result = json.loads(raw.decode('utf-8'))
        message = result['choices'][0]['message']
        if not isinstance(message, dict) or message.get('role') != 'assistant':
            raise ValueError
        content = message.get('content')
        if content is not None and not isinstance(content, str):
            raise ValueError
        calls = message.get('tool_calls')
        if calls is not None:
            if not isinstance(calls, list) or not calls:
                raise ValueError
            for call in calls:
                if (not isinstance(call, dict) or not isinstance(call.get('id'), str)
                        or not call['id'] or call.get('type') != 'function'
                        or not isinstance(call.get('function'), dict)
                        or not isinstance(call['function'].get('name'), str)
                        or not call['function']['name']
                        or not isinstance(call['function'].get('arguments'), str)):
                    raise ValueError
        if content is None and not calls:
            raise ValueError
        parsed = {'role': 'assistant', 'content': content}
        if calls is not None:
            parsed['tool_calls'] = calls
        return parsed
    except (ValueError, TypeError, KeyError, IndexError, UnicodeError, RecursionError):
        raise QwenError('Resposta JSON inválida ou incompleta do provedor.') from None
