"""Protus: assistente interativa de linha de comando, sem dependências externas.

A interface dos comandos é explícita: digite `ajuda` para ver os aliases.
"""
import ast
import datetime
import json
import math
import operator
import random
import re
import secrets
import socket
import string
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import webbrowser

from geradorHTML import salvar_arquivo
from agent import Agente, AVISO_API


# A ajuda é gerada desta única tabela; o mesmo registro dirige o parser.
COMANDOS = [
    ('ajuda', ('ajuda', 'help', 'ver'), '', 'Mostra esta ajuda.'),
    ('sair', ('sair', 'parar', 'exit', 'quit'), '', 'Encerra o Protus.'),
    ('pesquisar', ('pesquisar', 'pesquisa'), '[termo]', 'Abre uma busca no Google.'),
    ('youtube', ('youtube', 'pesquisar youtube', 'pesquisar no youtube'), '[termo]', 'Abre uma busca no YouTube.'),
    ('abrir', ('abrir',), '[URL]', 'Abre uma URL http ou https.'),
    ('horas', ('horas', 'hora', 'relógio', 'relogio'), '', 'Mostra a hora local.'),
    ('piada', ('conte uma piada', 'contar piada', 'piada'), '', 'Conta uma piada.'),
    ('poema', ('criar poema', 'poema'), '', 'Mostra um poema.'),
    ('historia', ('criar história', 'criar historia', 'história', 'historia'), '', 'Mostra uma história.'),
    ('recomendar', ('recomendar livro ou filme', 'recomendar', 'recomendação', 'recomendacao'), '', 'Recomenda um livro e um filme.'),
    ('aprender', ('aprender programação', 'aprender programacao'), '[variável|loop|função]', 'Explica um conceito de programação.'),
    ('nota', ('notepad', 'nota', 'bloco de notas'), '', 'Escreve e salva uma nota UTF-8.'),
    ('html', ('gerar html', 'html'), '', 'Gera um documento HTML.'),
    ('calculadora', ('modo calculadora', 'calculadora', 'calcular'), '[expressão]', 'Calcula ou inicia o modo calculadora.'),
    ('senha', ('criar senha segura', 'senha'), '[comprimento]', 'Gera senha aleatória (12–128 caracteres).'),
    ('wikipedia', ('busque por', 'wikipedia', 'wikipédia'), '[termo]', 'Busca um resumo na Wikipédia em português.'),
    ('ping', ('ping',), '[host]', 'Executa até 4 pings explícitos, com limite de tempo.'),
    ('rede', ('internet', 'rede'), '', 'Mostra rotas e endereços disponíveis, sem varredura.'),
    ('estado', ('status', 'estado'), '', 'Mostra informações locais; não detecta dispositivos.'),
    ('ia', ('modo ia', 'ia'), '[pergunta]', 'Inicia sessão de IA ou envia uma pergunta.'),
    ('clear', ('clear', 'limpar'), '', 'Limpa a tela em terminais compatíveis.'),
    ('oi', ('oi', 'olá', 'ola'), '', 'Cumprimenta.'),
    ('obrigado', ('obrigado', 'obrigada', 'agradecimento'), '', 'Responde ao agradecimento.'),
    ('suporte', ('suporte',), '', 'Informações gerais sobre o projeto.'),
]


def mostrar_ajuda():
    print('Comandos (aliases separados por /):')
    for _, aliases, argumento, descricao in COMANDOS:
        print(f"  {' / '.join(aliases)} {argumento} — {descricao}")


def identificar_comando(texto):
    texto = texto.strip()
    # Comparar apenas o prefixo de comando; os argumentos mantêm caixa e conteúdo.
    aliases = sorted(((alias, nome) for nome, nomes, _, _ in COMANDOS for alias in nomes),
                     key=lambda item: len(item[0]), reverse=True)
    for alias, nome in aliases:
        prefixo = texto[:len(alias)]
        if prefixo.casefold() == alias.casefold() and (len(texto) == len(alias) or texto[len(alias)].isspace()):
            return nome, texto[len(alias):].strip()
    return None, ''


def abrir_navegador(url):
    try:
        if not webbrowser.open(url):
            print('Não foi possível abrir o navegador. URL:', url)
            return False
        return True
    except (OSError, webbrowser.Error) as erro:
        print('Não foi possível abrir o navegador:', erro, '\nURL:', url)
        return False


def abrir_url(url):
    try:
        p = urllib.parse.urlsplit(url)
        if p.scheme.lower() not in ('http', 'https') or not p.hostname or p.username is not None or p.password is not None or any(c.isspace() or ord(c) < 32 for c in url):
            raise ValueError
        _ = p.port
    except ValueError:
        print('Informe uma URL válida começando por http:// ou https://, sem credenciais.')
        return False
    return abrir_navegador(url)


def pesquisar(termo, youtube=False):
    if not termo:
        termo = input('Termo de pesquisa: ').strip()
    if not termo:
        print('Informe um termo de pesquisa.')
        return
    base = 'https://www.youtube.com/results?' if youtube else 'https://www.google.com/search?'
    chave = 'search_query' if youtube else 'q'
    abrir_navegador(base + urllib.parse.urlencode({chave: termo}))


# Apenas números e operadores aritméticos. Todas as etapas têm limites de recursos.
_OPERACOES = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
              ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
              ast.Mod: operator.mod, ast.Pow: operator.pow}
_UNARIOS = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def calcular(expressao):
    expressao = expressao.replace('×', '*').replace('÷', '/').strip()
    if not expressao or len(expressao) > 256:
        raise ValueError('A expressão deve ter entre 1 e 256 caracteres.')
    try:
        arvore = ast.parse(expressao, mode='eval')
    except (SyntaxError, ValueError, RecursionError) as erro:
        raise ValueError('Expressão inválida.') from erro
    if sum(1 for _ in ast.walk(arvore)) > 64:
        raise ValueError('Expressão complexa demais.')

    def verificar(numero):
        if type(numero) not in (int, float):
            raise ValueError('Somente números são permitidos.')
        if isinstance(numero, int) and numero.bit_length() > 256:
            raise ValueError('Número inteiro grande demais.')
        if isinstance(numero, float) and (not math.isfinite(numero) or abs(numero) > 1e100):
            raise ValueError('Número fora do limite.')
        return numero

    def visitar(no, profundidade=0):
        if profundidade > 16:
            raise ValueError('Expressão aninhada demais.')
        if isinstance(no, ast.Constant):
            return verificar(no.value)
        if isinstance(no, ast.UnaryOp) and type(no.op) in _UNARIOS:
            return verificar(_UNARIOS[type(no.op)](visitar(no.operand, profundidade + 1)))
        if isinstance(no, ast.BinOp) and type(no.op) in _OPERACOES:
            a = visitar(no.left, profundidade + 1)
            b = visitar(no.right, profundidade + 1)
            if isinstance(no.op, ast.Pow):
                if type(b) is not int or abs(b) > 16:
                    raise ValueError('A potência exige expoente inteiro entre -16 e 16.')
                if isinstance(a, int) and b > 0 and a.bit_length() * b > 256:
                    raise ValueError('Resultado da potência seria grande demais.')
            try:
                return verificar(_OPERACOES[type(no.op)](a, b))
            except (ArithmeticError, OverflowError) as erro:
                raise ValueError('Operação impossível ou fora do limite.') from erro
        raise ValueError('Use apenas números e operadores + - * / // % ** e parênteses.')
    return visitar(arvore.body)


def modo_calculadora():
    print("Modo calculadora; digite 'sair' para voltar.")
    while True:
        try:
            expressao = input('Expressão: ')
        except (EOFError, KeyboardInterrupt):
            print('\nCalculadora encerrada.')
            return
        if expressao.strip().casefold() in ('sair', 'voltar'):
            return
        try:
            print('Resultado:', calcular(expressao))
        except ValueError as erro:
            print('Erro ao calcular:', erro)


def criar_senha_segura(tamanho=16):
    if not 12 <= tamanho <= 128:
        raise ValueError('O comprimento deve estar entre 12 e 128.')
    alfabeto = string.ascii_letters + string.digits + '!@#$%_-+'
    return ''.join(secrets.choice(alfabeto) for _ in range(tamanho))


def buscar_wikipedia(termo):
    if not termo:
        termo = input('Termo para a Wikipédia: ').strip()
    if not termo:
        print('Informe um termo.')
        return
    params = urllib.parse.urlencode({'action': 'query', 'generator': 'search', 'gsrsearch': termo,
                                    'gsrlimit': 1, 'prop': 'extracts', 'exintro': 1,
                                    'explaintext': 1, 'exsentences': 2, 'format': 'json',
                                    'formatversion': 2})
    req = urllib.request.Request('https://pt.wikipedia.org/w/api.php?' + params,
                                 headers={'User-Agent': 'Protus/1.0 (assistente de linha de comando)'})
    try:
        with urllib.request.urlopen(req, timeout=8) as resposta:
            dados = json.loads(resposta.read(1024 * 1024 + 1).decode('utf-8'))
        paginas = dados.get('query', {}).get('pages', [])
        if paginas:
            print('Wikipédia —', paginas[0].get('title', termo))
            print(paginas[0].get('extract') or 'Resumo indisponível; a página pode ser de desambiguação.')
        else:
            print('Nenhum resultado encontrado na Wikipédia.')
    except (OSError, ValueError, KeyError, TypeError) as erro:
        print('Não foi possível consultar a Wikipédia:', erro)


def nota():
    print("Bloco de notas: escreva linhas; digite 'salvar' em uma linha para concluir.")
    linhas = []
    while True:
        linha = input()
        if linha.strip().casefold() == 'salvar':
            break
        linhas.append(linha)
    caminho = input('Caminho do arquivo: ').strip()
    try:
        if salvar_arquivo(caminho, '\n'.join(linhas)):
            print(f'Nota salva em "{caminho}".')
    except (OSError, ValueError) as erro:
        print('Não foi possível salvar a nota:', erro)


def executar_comando_rede(argumentos, timeout=8):
    try:
        resultado = subprocess.run(argumentos, capture_output=True, text=True, errors='replace', timeout=timeout, check=False)
        if resultado.stdout.strip():
            print(resultado.stdout.rstrip())
        if resultado.stderr.strip():
            print(resultado.stderr.rstrip())
        if resultado.returncode:
            print(f'Comando terminou com código {resultado.returncode}; dados podem estar indisponíveis.')
        return resultado.returncode == 0
    except FileNotFoundError:
        print(f'Utilitário "{argumentos[0]}" não encontrado; instale-o para usar esta função.')
    except subprocess.TimeoutExpired:
        print('Tempo limite atingido; resultado inconclusivo.')
    except OSError as erro:
        print('Não foi possível executar o utilitário:', erro)
    return False


def ping(host):
    if not host:
        host = input('Host ou IP para ping: ').strip()
    # Não permitir opções, espaços, URLs ou metacaracteres; sem shell.
    if len(host) > 253 or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.:-]*', host):
        print('Informe apenas um hostname ou endereço IP válido, sem opções ou URL.')
        return
    print('Executando até 4 pings; ausência de resposta não prova que o host está offline.')
    executar_comando_rede(['ping', '-c', '4', '-W', '2', host], timeout=12)


def rede():
    print('Endereços locais informados por ip:')
    executar_comando_rede(['ip', 'address', 'show'])
    print('Tabela de rotas locais:')
    executar_comando_rede(['ip', 'route', 'show'])
    print('Esses dados não comprovam acesso à internet; nenhuma varredura foi feita.')


def estado():
    try:
        nome = socket.gethostname()
        print('Nome local:', nome)
        enderecos = sorted({x[4][0] for x in socket.getaddrinfo(nome, None, type=socket.SOCK_STREAM)})
        print('Endereços resolvidos para o nome local:', ', '.join(enderecos) or 'nenhum')
        print('Eles podem ser loopback ou não representar a interface ativa.')
    except OSError as erro:
        print('Informações locais indisponíveis:', erro)
    print('A conectividade e os dispositivos da rede não foram verificados; nenhuma varredura foi feita.')


def modo_ia():
    agente = Agente()
    print("Modo IA: histórico novo. Digite 'voltar' ou 'sair' para voltar; 'limpar histórico' para reiniciar.")
    print(AVISO_API)
    while True:
        try:
            entrada = input('IA — você: ').strip()
            if entrada.casefold() in ('voltar', 'sair'):
                break
            if entrada.casefold() == 'limpar histórico':
                agente.limpar()
            elif entrada:
                print('Protus IA:', agente.responder(entrada))
        except (EOFError, KeyboardInterrupt):
            print('\nSessão de IA encerrada.')
            break


_agente_padrao = None


def perguntar_ia(texto):
    global _agente_padrao
    if not texto.strip():
        return
    if _agente_padrao is None:
        _agente_padrao = Agente()
    print('Protus IA:', _agente_padrao.responder(texto))


PIADAS = ['Por que o livro de matemática estava triste? Porque tinha muitos problemas!',
          'O que o zero disse para o oito? Que cinto maneiro!',
          'Por que os cientistas não confiam nos átomos? Porque eles compõem tudo!']
POEMAS = ['Nas asas do vento, nosso amor alçou voo,\nNo suave murmúrio do rio, encontramos abrigo.',
           'Em cada aurora, a esperança renasce,\nMesmo nas sombras, a luz busca seu espaço.']
HISTORIAS = ['Em uma ilha misteriosa, exploradores partem em busca de um tesouro perdido.',
             'Um detetive investiga uma mansão isolada, onde cada pessoa guarda um segredo.',
             'Em um mundo mágico, uma jovem descobre seus poderes e ajuda a salvar seu reino.']
RECOMENDACOES = [('Duna, de Frank Herbert', 'Blade Runner 2049'),
                 ('Orgulho e Preconceito, de Jane Austen', 'Simplesmente Acontece'),
                 ('O Guia do Mochileiro das Galáxias, de Douglas Adams', 'Debi & Lóide')]
CONCEITOS = {'variável': 'Uma variável associa um nome a um valor. Exemplo em Python: idade = 25',
             'variavel': 'Uma variável associa um nome a um valor. Exemplo em Python: idade = 25',
             'loop': 'Um loop repete ações. Exemplo em Python: for i in range(5): print(i)',
             'função': 'Uma função agrupa ações reutilizáveis. Exemplo: def dobro(x): return x * 2',
             'funcao': 'Uma função agrupa ações reutilizáveis. Exemplo: def dobro(x): return x * 2'}


def executar(texto):
    if not texto.strip():
        return True
    comando, argumento = identificar_comando(texto)
    if not comando:
        perguntar_ia(texto)
    elif comando == 'sair':
        return False
    elif comando == 'ajuda':
        mostrar_ajuda()
    elif comando in ('pesquisar', 'youtube'):
        pesquisar(argumento, comando == 'youtube')
    elif comando == 'abrir':
        abrir_url(argumento or input('URL http(s): ').strip())
    elif comando == 'horas':
        print('Hora local:', datetime.datetime.now().strftime('%H:%M'))
    elif comando == 'piada':
        print(random.choice(PIADAS))
    elif comando == 'poema':
        print(random.choice(POEMAS))
    elif comando == 'historia':
        print(random.choice(HISTORIAS))
    elif comando == 'recomendar':
        livro, filme = random.choice(RECOMENDACOES)
        print('Livro:', livro, '\nFilme:', filme)
    elif comando == 'aprender':
        conceito = (argumento or input('Conceito (variável, loop, função): ')).strip().casefold()
        print(CONCEITOS.get(conceito, 'Conceito não disponível. Escolha variável, loop ou função.'))
    elif comando == 'nota':
        nota()
    elif comando == 'html':
        import geradorHTML
        geradorHTML.main()
    elif comando == 'calculadora':
        if argumento:
            try:
                print('Resultado:', calcular(argumento))
            except ValueError as erro:
                print('Erro ao calcular:', erro)
        else:
            modo_calculadora()
    elif comando == 'senha':
        try:
            tamanho = int(argumento) if argumento else 16
            print('Senha gerada:', criar_senha_segura(tamanho))
        except ValueError as erro:
            print('Comprimento inválido. Use um inteiro entre 12 e 128.', erro)
    elif comando == 'wikipedia':
        buscar_wikipedia(argumento)
    elif comando == 'ping':
        ping(argumento)
    elif comando == 'rede':
        rede()
    elif comando == 'estado':
        estado()
    elif comando == 'ia':
        if argumento:
            perguntar_ia(argumento)
        else:
            modo_ia()
    elif comando == 'clear':
        print('\033[2J\033[H', end='')
    elif comando == 'oi':
        print('Olá! Como posso ajudar?')
    elif comando == 'obrigado':
        print('De nada!')
    elif comando == 'suporte':
        print('Protus é um projeto de assistente de linha de comando.')
    return True


def assistente():
    global _agente_padrao
    _agente_padrao = Agente()
    print('Olá! Eu sou Protus. Digite ajuda para listar os comandos.')
    while True:
        try:
            entrada = input('Você: ')
            if entrada.strip() and not executar(entrada):
                break
        except (EOFError, KeyboardInterrupt):
            print()
            break
    print('Até logo!')


if __name__ == '__main__':
    assistente()
