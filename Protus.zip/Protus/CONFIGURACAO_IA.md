# IA no Protus

## Configuração e início no Termux

O padrão é o endpoint `https://openrouter.ai/api/v1/chat/completions` e o modelo `qwen/qwen3.8-27b`. A disponibilidade, os preços e eventuais créditos dependem do provedor e do modelo; confira-os no provedor antes de usar. A IA pode gerar custos, inclusive com múltiplas requisições por turno. Não há garantia de que o modelo esteja disponível.

No Termux, a partir da pasta do projeto, digite a chave apenas quando solicitada, sem exibi-la nem colocá-la no histórico de comandos:

```sh
read -r -s -p 'Chave OpenRouter: ' OPENROUTER_API_KEY
printf '\n'
export OPENROUTER_API_KEY
python protus.py
unset OPENROUTER_API_KEY
```

O valor permanece no ambiente do shell e de seus processos filhos até ser removido ou o shell ser encerrado; não compartilhe sessão ou ambiente com processos não confiáveis. Não coloque chaves no código, em arquivos, nas mensagens ou na URL.

Para endpoint **não loopback**, é obrigatória uma chave: `OPENROUTER_API_KEY` tem precedência sobre `PROTUS_API_KEY`. Para `localhost`, `127.0.0.1` ou `[::1]`, usa-se somente `PROTUS_API_KEY`, se definida; `OPENROUTER_API_KEY` não é usada automaticamente e o servidor local pode funcionar sem chave. Ao usar `qwen.chat` diretamente, uma chave passada em `api_key` tem precedência sobre o ambiente em ambos os casos.

`PROTUS_QWEN_ENDPOINT` e `PROTUS_QWEN_MODEL` substituem os padrões. O cliente exige HTTPS, exceto HTTP em loopback, e não aceita credenciais na URL. Para serviço local, configure o endereço e modelo reais do seu servidor compatível com Chat Completions, por exemplo:

```sh
unset OPENROUTER_API_KEY PROTUS_API_KEY
export PROTUS_QWEN_ENDPOINT='http://127.0.0.1:8000/v1/chat/completions'
export PROTUS_QWEN_MODEL='nome-do-modelo-local'
python protus.py
```

O exemplo pressupõe servidor e modelo já disponíveis; o Protus não os instala. Se o serviço local exigir autenticação, leia sua chave silenciosamente com `read -r -s` para `PROTUS_API_KEY` e exporte-a. Escolha um endpoint confiável: HTTPS também permite hosts privados; não é uma proteção geral contra destinos indesejados.

## Uso e privacidade

Digite `modo ia` ou `ia` para uma sessão nova; `voltar` ou `sair` retorna ao menu e `limpar histórico` reinicia o contexto. `ia pergunta` e entradas não reconhecidas usam uma sessão separada, reiniciada ao abrir o Protus. Históricos ficam em memória e podem ser limpos ao atingir limites ou em falhas; forneça o contexto novamente quando necessário.

**Mensagens, histórico e resultados de ferramentas podem ser enviados ao endpoint configurado e ao provedor da IA.** Não envie dados sensíveis. As ferramentas de pesquisa consultam somente a Wikipédia em português, não um buscador geral; a ferramenta separada de leitura pode acessar uma página HTTPS pública. Conteúdo externo é não confiável e não deve ser tratado como instrução; não há garantia absoluta contra instruções maliciosas.

Na integração do agente, cada pesquisa ou leitura de página exige `sim` em `/dev/tty`, após mostrar consulta ou destino; sem TTY é recusada. Cada instalação exige confirmação humana independente em `/dev/tty`, digitando **exatamente** o comando completo exibido, incluindo caminho de `pkg`, `install -y` e pacote. O `-y` aprova automaticamente perguntas do gerenciador depois dessa confirmação; pacotes podem executar scripts com as permissões do usuário. A instalação é recusada como root e depende do Termux e de seus repositórios configurados. Após 300 segundos, o processo pode ser interrompido, deixando alterações parciais; confira o estado antes de tentar novamente. Inspeção local não exige confirmação.

Essas confirmações são das **ferramentas chamadas pela IA**, não dos comandos legados do menu: por exemplo, `pesquisar`/`youtube` abrem buscas no navegador, `abrir` abre URL e `wikipedia` consulta a Wikipédia sem essa confirmação em TTY. Há até cinco chamadas à API e cinco chamadas de ferramentas por turno; resultados de ferramentas no histórico são limitados a 8.000 caracteres.
